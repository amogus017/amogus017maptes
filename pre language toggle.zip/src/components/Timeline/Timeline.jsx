// components/Timeline/Timeline.jsx
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import './Timeline.css';

const Victoria3Timeline = ({ onYearChange, currentYear: externalYear, isPanelOpen }) => {
  const [year, setYear] = useState(1350);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isEditingYear, setIsEditingYear] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const scrollRef = useRef(null);
  const isDragging = useRef(false);
  const isDraggingTimeout = useRef(null);
  const isProgrammaticScroll = useRef(false);
  const isProgrammaticScrollTimeout = useRef(null);

  const MIN_YEAR = 400;
  const MAX_YEAR = 1600;

  const PIXELS_PER_YEAR = 2;
  const TOTAL_WIDTH = (MAX_YEAR - MIN_YEAR) * PIXELS_PER_YEAR;
  const yearToPixel = useCallback((y) => (y - MIN_YEAR) * PIXELS_PER_YEAR, []);
  const pixelToYear = useCallback((px) => Math.round(px / PIXELS_PER_YEAR) + MIN_YEAR, []);

  const handleYearChange = (newYear) => {
    setYear(newYear);
    onYearChange(newYear);
  };

  const scrollToYear = useCallback((newYear, smooth = false) => {
    if (!scrollRef.current) return;
    const frame = scrollRef.current;
    const targetScroll = yearToPixel(newYear) - frame.clientWidth / 2;

    isProgrammaticScroll.current = true;
    frame.scrollTo({
      left: Math.max(0, targetScroll),
      behavior: smooth ? 'smooth' : 'auto',
    });

    clearTimeout(isProgrammaticScrollTimeout.current);
    isProgrammaticScrollTimeout.current = setTimeout(() => {
      isProgrammaticScroll.current = false;
    }, smooth ? 600 : 50);
  }, [yearToPixel]);

  // Sync to externally-driven year changes (e.g. kingdom search select)
  useEffect(() => {
    if (externalYear == null || externalYear === year) return;
    setYear(externalYear);
    scrollToYear(externalYear, true);
  }, [externalYear]); // scrollToYear is stable; year excluded to avoid loop

  // Confirm typed year — clamp silently to MIN/MAX
  const confirmYear = useCallback(() => {
    const parsed = parseInt(inputValue);
    const clamped = isNaN(parsed)
      ? year
      : Math.max(MIN_YEAR, Math.min(MAX_YEAR, parsed));
    handleYearChange(clamped);
    scrollToYear(clamped, true);
    setIsEditingYear(false);
  }, [inputValue, year, scrollToYear, handleYearChange]);

  // Auto-play effect
  useEffect(() => {
    let interval;
    if (isPlaying) {
      interval = setInterval(() => {
        setYear(current => {
          const next = current + 1;
          if (next > MAX_YEAR) {
            setIsPlaying(false);
            return MIN_YEAR;
          }
          onYearChange(next);
          scrollToYear(next, true);
          return next;
        });
      }, 150);
    }
    return () => clearInterval(interval);
  }, [isPlaying, onYearChange, scrollToYear]);

  const rulerMarks = useMemo(() => {
    const marks = [];
    for (let tickYear = MIN_YEAR; tickYear <= MAX_YEAR; tickYear += 5) {
      const px = yearToPixel(tickYear);
      const isMajor = tickYear % 100 === 0;
      const isMedium = tickYear % 50 === 0 && !isMajor;
      const isMinor = tickYear % 25 === 0 && !isMedium && !isMajor;

      let tickClass = 'micro';
      if (isMajor) tickClass = 'major';
      else if (isMedium) tickClass = 'medium';
      else if (isMinor) tickClass = 'minor';

      marks.push(
        <div
          key={`tick-${tickYear}`}
          className={`ruler-tick ${tickClass}`}
          style={{ left: `${px}px` }}
        />
      );

      if (isMajor || isMedium) {
        marks.push(
          <div
            key={`label-${tickYear}`}
            className={`ruler-label ${isMajor ? 'major-label' : 'medium-label'}`}
            style={{ left: `${px}px` }}
          >
            {tickYear}
          </div>
        );
      }
    }
    return marks;
  }, [yearToPixel]);

  return (
    <div className={`victoria3-timeline${isPanelOpen ? ' panel-open' : ''}`}>

      <div className="v3-slider-container">

        {/* Year tooltip — click to edit */}
        {isEditingYear ? (
          <input
            className="year-tooltip year-tooltip-input"
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onBlur={confirmYear}
            onKeyDown={(e) => {
              if (e.key === 'Enter') confirmYear();
              if (e.key === 'Escape') setIsEditingYear(false);
            }}
            autoFocus
          />
        ) : (
          <div
            className="year-tooltip year-tooltip-editable"
            role="button"
            tabIndex={0}
            onClick={() => {
              setInputValue(String(year));
              setIsEditingYear(true);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                setInputValue(String(year));
                setIsEditingYear(true);
              }
            }}
            title="Click to type a year"
            aria-label={`Current year: ${year}. Click to edit.`}
          >
            {year}
          </div>
        )}

        <div
          className="slider-frame"
          ref={scrollRef}
          onScroll={(e) => {
            if (isDragging.current || isProgrammaticScroll.current) return;
            const target = e.target;
            const viewportCenter = target.scrollLeft + target.clientWidth / 2;
            const snapped = Math.max(MIN_YEAR, Math.min(MAX_YEAR, pixelToYear(viewportCenter)));
            setYear(snapped);
            onYearChange(snapped);
          }}
        >
          <div className="timeline-scroll-wrapper">
            <div className="timeline-inner" style={{ width: `${TOTAL_WIDTH}px` }}>

              <div className="ruler-background">
                <div className="ruler-baseline" style={{ width: `${TOTAL_WIDTH}px` }} />
                {rulerMarks}
              </div>

              <div className="slider-track">
                <div className="slider-wrapper">
                  <input
                    type="range"
                    className="v3-slider"
                    aria-label="Select year"
                    aria-valuemin={MIN_YEAR}
                    aria-valuemax={MAX_YEAR}
                    aria-valuenow={year}
                    aria-valuetext={`Year ${year} CE`}
                    min={MIN_YEAR}
                    max={MAX_YEAR}
                    value={year}
                    onChange={(e) => {
                      const newYear = parseInt(e.target.value);
                      handleYearChange(newYear);

                      if (scrollRef.current) {
                        const frame = scrollRef.current;
                        const thumbPx = yearToPixel(newYear);
                        const scrollLeft = frame.scrollLeft;
                        const viewportWidth = frame.clientWidth;
                        const EDGE_THRESHOLD = viewportWidth * 0.1;

                        const distFromLeft = thumbPx - scrollLeft;
                        const distFromRight = scrollLeft + viewportWidth - thumbPx;

                        if (distFromLeft < EDGE_THRESHOLD || distFromRight < EDGE_THRESHOLD) {
                          frame.scrollLeft = Math.max(0, thumbPx - viewportWidth / 2);
                        }
                      }

                      clearTimeout(isDraggingTimeout.current);
                      isDraggingTimeout.current = setTimeout(() => {
                        isDragging.current = false;
                      }, 150);
                    }}
                    onPointerDown={() => {
                      if (scrollRef.current) scrollRef.current.style.touchAction = 'none';
                    }}
                    onPointerUp={() => {
                      if (scrollRef.current) scrollRef.current.style.touchAction = 'pan-x';
                    }}
                    onPointerCancel={() => {
                      if (scrollRef.current) scrollRef.current.style.touchAction = 'pan-x';
                    }}
                    style={{ width: `${TOTAL_WIDTH}px` }}
                  />
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Victoria3Timeline;